#!/usr/bin/env python3
"""
YouTube AI Studio — Mobil Masofaviy Boshqaruv (Mobile Remote Studio)
Ushbu skript Veb Studiyani ishga tushiradi va Cloudflare Tunnel orqali
telefoningiz brauzeri uchun xavfsiz HTTPS havola hamda QR kod taqdim etadi.
Dunyoning istalgan joyidan (4G/5G/Wi-Fi orqali) terminalsiz ishlatishingiz mumkin!
"""

import os
import sys
import time
import re
import socket
import subprocess
from pathlib import Path

CLOUDFLARED_BIN = Path(__file__).parent / "cloudflared.exe"
PORT = 8501


def get_local_ip() -> str:
    """Kompyuterning mahalliy Wi-Fi IP manzilini aniqlaydi."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def print_banner(public_url: str, local_ip: str):
    print("\n" + "=" * 70, flush=True)
    print("🚀 YOUTUBE AI STUDIO — MOBIL TELEFONDA ISHLATISH TAYYOR!", flush=True)
    print("=" * 70, flush=True)
    print(f"\n📱 1. DUNYONING ISTALGAN JOYIDAN (4G / 5G / Wi-Fi):", flush=True)
    print(f"👉 Havola: {public_url}", flush=True)
    print(f"\n📶 2. AGAR BIR XIL WI-FI TARMOQDA BO'LSANGIZ (Lokal):", flush=True)
    print(f"👉 Havola: http://{local_ip}:{PORT}", flush=True)
    print("\n" + "-" * 70, flush=True)
    print("💡 TELEFONINGIZDA ISHLATISH YO'LI:", flush=True)
    print("  1. Telefoningiz kamerasi bilan pastdagi QR kodni skanerlang")
    print("     yoki yuqoridagi 'https://...' havolasini brauzeringizda oching.")
    print("  2. Studiya telefoningizda to'liq ochiladi!")
    print("  3. 1 ta klik bilan video yaratib, YouTube kanalga yuklashingiz mumkin.")
    print("=" * 70 + "\n", flush=True)

    # QR kodni matn ko'rinishida ekranga chiqarish
    try:
        import qrcode
        qr = qrcode.QRCode(border=2)
        qr.add_data(public_url)
        qr.make(fit=True)
        qr.print_ascii(invert=True)

        # PNG rasm sifatida ham saqlab qo'yamiz
        qr_img = qrcode.make(public_url)
        qr_img.save("telefon_qr_kod.png")
        print("\n📸 QR kod rasmi 'telefon_qr_kod.png' fayliga ham saqlandi.", flush=True)
    except Exception:
        pass

    # Havolani oddiy txt faylga ham yozib qo'yamiz
    with open("telefon_havolasi.txt", "w", encoding="utf-8") as f:
        f.write(f"YouTube AI Studio Mobil Havolasi:\n{public_url}\n\nLokal Wi-Fi Havolasi:\nhttp://{local_ip}:{PORT}\n")
    print("💾 Havola 'telefon_havolasi.txt' fayliga saqlandi.\n", flush=True)
    print("🛑 To'xtatish uchun: Ushbu oynada Ctrl + C tugmalarini bosing.\n", flush=True)


def main():
    if not CLOUDFLARED_BIN.exists():
        print(f"[-] '{CLOUDFLARED_BIN}' topilmadi! Yuklanmoqda...", flush=True)
        import urllib.request
        url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
        urllib.request.urlretrieve(url, str(CLOUDFLARED_BIN))
        print("[+] cloudflared.exe muvaffaqiyatli yuklandi.\n", flush=True)

    local_ip = get_local_ip()

    print("[*] Streamlit Veb Studiya ishga tushirilmoqda...", flush=True)
    streamlit_cmd = [
        sys.executable, "-m", "streamlit", "run", "web_dashboard.py",
        "--server.port", str(PORT),
        "--server.address", "0.0.0.0",
        "--server.enableCORS", "false",
        "--server.enableXsrfProtection", "false",
        "--browser.gatherUsageStats", "false",
        "--server.headless", "true",
    ]
    streamlit_proc = subprocess.Popen(
        streamlit_cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    print("[*] Cloudflare xavfsiz tunnel ochilmoqda...", flush=True)
    tunnel_cmd = [
        str(CLOUDFLARED_BIN), "tunnel",
        "--url", f"http://127.0.0.1:{PORT}",
        "--no-autoupdate",
    ]
    tunnel_proc = subprocess.Popen(
        tunnel_cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )

    public_url = None
    start_time = time.time()
    url_pattern = re.compile(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com")

    # Tunnel loglaridan HTTPS havolani qidiramiz
    while time.time() - start_time < 30:
        line = tunnel_proc.stdout.readline()
        if not line:
            break
        match = url_pattern.search(line)
        if match:
            public_url = match.group(0)
            break

    if not public_url:
        print("[-] Xatolik: Cloudflare havolasi olinmadi. Mahalliy tarmoqdan foydalanishingiz mumkin:", flush=True)
        print(f"👉 http://{local_ip}:{PORT}", flush=True)
    else:
        print_banner(public_url, local_ip)

    try:
        while True:
            time.sleep(1)
            if streamlit_proc.poll() is not None:
                print("[-] Streamlit to'xtadi.")
                break
            if tunnel_proc.poll() is not None:
                print("[-] Cloudflare tunnel to'xtadi.")
                break
    except KeyboardInterrupt:
        print("\n[*] Tizim to'xtatilmoqda...")
    finally:
        try:
            streamlit_proc.terminate()
            tunnel_proc.terminate()
        except Exception:
            pass
        print("[+] Xizmat to'xtatildi.")


if __name__ == "__main__":
    main()
