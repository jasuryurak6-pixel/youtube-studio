---
title: YouTube AI Studio
emoji: 🎬
colorFrom: red
colorTo: purple
sdk: streamlit
sdk_version: "1.38.0"
app_file: web_dashboard.py
pinned: false
license: mit
---

# 🚀 YouTube AI Studio (2D Animatsion Hikoyalar & Koinot Faktlari)

Day One Films uslubidagi 2D Animatsion Hikoyalar (`jasuryurak6@gmail.com`) va Kosmik Faktlar (`youtubekanal0004@gmail.com`) uchun avtomatlashtirilgan video generator va YouTube yuklovchisi.

## 📱 Xususiyatlari
- 📖 **2D Animatsion Hikoyalar** (16:9 yoki 9:16 Shorts)
- 🌌 **Koinot & Dunyo Faktlari** (16:9 Hujjatli film)
- ⚡ **YouTube Shorts** (9:16 Vertikal)
- 🏛️ **Falsafa & Motivatsiya**
- 125+ saralangan toza mavzular bazasi
- YouTube API orqali avtomatik kanallarga yuklash
