#!/usr/bin/env python3
"""
YouTube AI Studio — Cloud Entry Point
Streamlit Cloud yoki Hugging Face Spaces uchun asosiy kirish nuqtasi.
"""
import os
import sys

# Loyiha papkasini qidiruv yo'liga qo'shish
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

# web_dashboard.py ni ishga tushirish
import web_dashboard
