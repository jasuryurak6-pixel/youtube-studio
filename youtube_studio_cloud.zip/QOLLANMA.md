# 🎬 YouTube AI Studio Pro — To'liq Qo'llanma

Ushbu tizim sun'iy intellekt (Gemini AI, Edge-TTS, Pixabay va FFmpeg) yordamida to'liq avtomatik tarzda turli yo'nalishdagi videolarni generatsiya qilish va ularni avtomatik ravishda YouTube kanallariga yuklash uchun yaratilgan.

---

## 🔍 1. Eski Fayllardagi Xatolar va Qilingan Tuzatishlar

Loyihadagi fayllar sinchiklab tekshirildi va quyidagi muhim xatoliklar aniqlanib, to'liq bartaraf etildi:

1. **Gemini API Modellari va 503/404 Xatosi:**
   - **Xatolik:** `GEMINI_MODEL_CHAIN` ro'yxatida `gemini-3.8-flash` birinchi o'ringa qo'yilgan edi. Ushbu modelga serverda yuklama oshganda `503 UNAVAILABLE` xatosi qaytib, jarayon to'xtab qolardi.
   - **Tuzatish:** Modellar zanjiri eng barqaror, tezkor va arzon modellar tartibida yangilandi:
     `["gemini-3.5-flash-lite", "gemini-3.5-flash", "gemini-flash-latest", "gemini-flash-lite-latest", "gemini-3.8-flash"]`.

2. **YouTube Video Havolasi (URL) Buzilganligi:**
   - **Xatolik:** `youtube_facts_agent.py` (411-qator) va `story_animation_agent.py` (848-qator) fayllarida havola quyidagicha xato yozilgan edi:
     `video_url = f"[https://www.youtube.com/watch?v=](https://www.youtube.com/watch?v=){response['id']}"`
     Natijada havola buzilib, veb dashboard uni o'qiy olmasdan xatolik berardi.
   - **Tuzatish:** Havola toza formatga keltirildi: `https://www.youtube.com/watch?v={response['id']}`.

3. **Kanal Token Fayllaridagi Nomuvofiqlik:**
   - **Xatolik:** `web_dashboard.py` da 2D Animatsiya uchun `token_file = "token_story.json"` deb belgilangan, ammo `story_animation_agent.py` faylida u `youtube_token.json` deb yozilgan edi. Bu tufayli veb interfeysdagi "Boshqa Gmailga yuklash" (`force_login`) tugmasi ishlamas edi.
   - **Tuzatish:** `channel_manager.py` yaratilib, barcha tokenlar (`token_facts.json`, `token_story.json`, `token_shorts.json`, `token_motivation.json`, `youtube_token.json`) yagona tizimga birlashtirildi.

4. **Pixabay 4K Kliplar Tufayli Sekin Yuklanish:**
   - **Xatolik:** Pixabay qidiruvida `best_file = variants.get("large")` birinchi o'ringa qo'yilgan edi. Bu har biri 200-300MB bo'lgan og'ir 4K videolarni yuklab olib, jarayonni 5-10 daqiqaga cho'zib yuborardi.
   - **Tuzatish:** `medium` (1080p/720p) birinchi o'ringa qo'yildi. Video sifati saqlangan holda yuklab olish **10 barobar tezlashdi**.

5. **Edge-TTS Tarmoq Uzilishlari:**
   - **Xatolik:** Ketma-ket 12-14 ta sahnaga ovoz yozganda Microsoft Edge-TTS ba'zan uzilib qolar va xatolik ushlanmasdan dastur yarmida to'xtab qolardi.
   - **Tuzatish:** Ovoz sintezida 3 martalik avtomatik qayta urinish (`retry`) va kechikish mexanizmi qo'shildi.

6. **Windows Konsolidagi Unicode/Emoji Xatosi (`cp1251`):**
   - **Xatolik:** Gemini sarlavhalarda emojilar (masalan: 🌊, 🚀, 🎬) qaytarganda Windows konsoli `UnicodeEncodeError: 'charmap'` berib dasturni to'xtatardi.
   - **Tuzatish:** Barcha skriptlarga Windows uchun `sys.stdout.reconfigure(encoding="utf-8")` va xavfsiz log funksiyasi qo'shildi.

7. **Mavzular Aralashib Ketishi va Juda Kamligi To'liq Hal Qilindi:**
   - **Xatolik:** Mavzular soni kam bo'lib, veb interfeysda yo'nalish o'zgarganda yoki "Tasodifiy Mavzu" bosilganda mavzular aralashib yoki qotib qolardi.
   - **Tuzatish:** Maxsus [topics_database.py](file:///c:/Users/user/Desktop/story_channel_agent/topics_database.py) bazasida **2D Hikoyalar uchun 125 ta O'zbekcha + 125 ta Inglizcha (jami 250 ta)** va **Koinot/Fan Faktlari uchun 125 ta O'zbekcha + 125 ta Inglizcha (jami 250 ta)** saralangan toza mavzular kiritildi.
   - [story_animation_agent.py](file:///c:/Users/user/Desktop/story_channel_agent/story_animation_agent.py) (`used_topics_story.json`) va [youtube_facts_agent.py](file:///c:/Users/user/Desktop/story_channel_agent/youtube_facts_agent.py) (`used_topics_facts.json`) uchun alohida xotiralar o'rnatildi — mavzular mutlaqo aralashmaydi va takrorlanmaydi.
   - Veb interfeysda `"Maxsus mavzu kiriting (yoki yuqoridagi tugmani bosing):"` maydoni, `🎲 Tasodifiy Mavzu` tugmasi va 100+ katalog ro'yxati bir zumda sinxronlashadigan qilib sozlandi.
   - Terminal (CLI) orqali ishga tushirilganda ham foydalanuvchidan maxsus mavzu kiritish so'raladi yoki Enter bosilganda yangi saralangan mavzu avtomatik tanlanadi.

---

## 🚀 2. Tizimdagi 4 Xil Video Generatsiya Yo'nalishi

Siz so'raganingizdek, har xil turdagi videolarni avtomatik yaratuvchi 4 ta to'liq mustaqil va sifatli agent ishga tushirildi:

| # | Yo'nalish | Format | Agent Fayli | Xususiyatlari |
|---|---|---|---|---|
| **1** | 🌌 **Kosmik & Dunyo Faktlari** | 16:9 Gorizontal | `youtube_facts_agent.py` | Pixabay HD kadrlari, kosmik ambient musiqa, professional subtitrlar, chuqur ilmiy ssenariy. |
| **2** | 📖 **2D Animatsion Hikoyalar** | 16:9 yoki 9:16 Shorts | `story_animation_agent.py` | Day One uslubida: 8 xil xona/joylashuv, STATUS BAR (Discipline, Mood, Energy), qora soya (Shadow demon), qahramon harakatlari, dialog pufakchalari. |
| **3** | ⚡ **Viral YouTube Shorts** | 9:16 Vertikal | `story_animation_agent.py` yoki `shorts_generator.py` | 30-50 soniyalik format: 2D Animatsiya yoki Dinamik Stock video variantlari bilan. |
| **4** | 🏛️ **Falsafa & Motivatsiya** | 16:9 yoki 9:16 | `motivation_agent.py` | Stoisizm (Marcus Aurelius, Seneca), og'ir kinematik bas, haykallar va tabiat kadrlari, qat'iyat va intizom mavzulari. |

---

## 💻 3. Veb Studiyani Ishga Tushirish

### A) Kompyuterda ishlatish:
1. Papkadagi `start_studio.bat` faylini ikki marta bosing yoki terminalda:
   ```bash
   python -m streamlit run web_dashboard.py
   ```
2. Kompyuter brauzerida `http://localhost:8501` ochiladi.

---

### 📱 B) Telefondan (Terminalsiz va Istalgan Joydan) Ishlatish:
Kompyuter yonida bo'lmasangiz ham, ko'chada yoki istalgan joyda telefoningizdan foydalanishingiz mumkin:
1. Papkadagi **[telefon_uchun_boshlash.bat](file:///c:/Users/user/Desktop/story_channel_agent/telefon_uchun_boshlash.bat)** faylini sichqoncha bilan ikki marta bosing.
2. Ekranda **xavfsiz HTTPS havola** (masalan: `https://...trycloudflare.com`) va **QR kod** paydo bo'ladi.
3. Telefoningiz kamerasi bilan QR kodni skanerlang yoki havolani telefoningiz brauzerida oching.
4. Studiya telefoningizda to'liq ochiladi — siz bemalol mavzu tanlab, 1 ta klik bilan video yaratib, YouTube kanalga yuklashingiz mumkin!
5. Havola har doim **`telefon_havolasi.txt`** faylida ham saqlanadi.

---

### Veb Studiya Bo'limlari:
- 🚀 **Video Generator:** Format, til (O'zbek, Ingliz, Rus, Turk), diktor ovozi va mavzuni tanlab, 1 klik bilan video yaratish. "🎲 Trend G'oya" tugmasi AI yordamida qiziqarli mavzular taklif qiladi.
- 📺 **Video Galereyasi & Pleyer:** Barcha yaratilgan videolarni brauzerning o'zida tomosha qilish, MP4 faylini yuklab olish yoki avval oflayn yaratilgan videoni 1 klik bilan YouTube'ga yuklash.
- 🔴 **YouTube Kanallari:** Bir nechta kanallarni boshqarish, kanal obunachilarini ko'rish va yangi YouTube kanalini Google orqali ulash.
- ⚙️ **Tizim & Diagnostika:** Gemini AI, Pixabay, Edge-TTS va FFmpeg holatini bir zumda test qilish.

---

## 🎯 4. YouTube Kanallari va Gmail Hisoblari Boshqaruvi

Siz talab qilganingizdek, 2 ta asosiy Gmail hisobi tizimga to'liq biriktirildi:

1. **`jasuryurak6@gmail.com`**
   - **Tegishli agent:** `story_animation_agent.py` (2D Animatsion Hikoyalar)
   - **Token fayli:** `token_jasuryurak6.json`
   - Veb studiyada "2D Animatsion Hikoyalar" tanlanganda avtomatik ravishda ushbu Gmail tanlanadi.

2. **`youtubekanal0004@gmail.com`**
   - **Tegishli agent:** `youtube_facts_agent.py` (Kosmik & Dunyo Faktlari)
   - **Token fayli:** `token_youtubekanal0004.json`
   - Veb studiyada "Kosmik & Dunyo Faktlari" tanlanganda avtomatik ravishda ushbu Gmail tanlanadi.

> **💡 Eslatma:** Veb studiyaga kirganingizda yoki terminalda skriptni yurgizganingizda tizim sizdan **qaysi Gmail kanalga yuklashni so'raydi**. Agar yangi hisob bilan kirsangiz, brauzer avtomatik ravishda ochilib, aynan o'sha Gmail hisobini tanlashingizni so'raydi!

---

## 🛠️ 5. Terminal Orqali Ishga Tushirish (CLI)

```bash
# 1. 2D Animatsion hikoya (avtomatik jasuryurak6@gmail.com kanaliga):
python story_animation_agent.py --lang uz --topic "Vaqtni qadrlash sabog'i"

# 2. Kosmik Hujjatli film (avtomatik youtubekanal0004@gmail.com kanaliga):
python youtube_facts_agent.py --lang uz --topic "Qora tuynuklar siri"

# 3. YouTube Shorts (9:16 Vertikal):
python shorts_generator.py --lang uz --topic "Nega dengiz suvi sho'r?"

# 4. Falsafiy motivatsion video:
python motivation_agent.py --lang uz --vertical --topic "Marcus Aurelius o'gitlari"

# Aniq bir Gmail ko'rsatib ishlatish:
python story_animation_agent.py --gmail jasuryurak6@gmail.com --lang uz

# Faqat diskka saqlash (YouTube'ga yuklamasdan):
python shorts_generator.py --lang uz --topic "AI kelajagi" --no-upload
```

