@echo off
title YouTube AI Studio Pro
chcp 65001 >nul
echo =====================================================================
echo                🎬 YouTube AI Studio Pro — Master Hub
echo =====================================================================
echo  Veb interfeys yuklanmoqda: http://localhost:8501
echo  Barcha video generatsiya agentlari (Faktlar, 2D, Shorts, Motivatsiya)
echo =====================================================================
python -m streamlit run web_dashboard.py
pause
