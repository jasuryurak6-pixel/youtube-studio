@echo off
chcp 65001 > nul
title YouTube AI Studio — Mobil Telefon Rejimi
color 0b

echo ======================================================================
echo           YOUTUBE AI STUDIO — MOBIL TELEFON REJIMI
echo ======================================================================
echo   Iltimos kuting, xavfsiz mobil havola yaratilmoqda...
echo ======================================================================

python mobile_remote_studio.py

pause
