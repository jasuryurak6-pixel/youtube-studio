#!/usr/bin/env python3
"""
YouTube AI Studio — Bulutga Yuklash Yordamchisi (Cloud Deployment Packager)
Ushbu skript loyihani Hugging Face Spaces yoki Streamlit Cloud ga yuklash uchun
barcha kerakli fayllarni ixcham 'youtube_studio_cloud.zip' arxiviga yig'ib beradi.
"""

import os
import sys
import zipfile
from pathlib import Path

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

OUTPUT_ZIP = "youtube_studio_cloud.zip"

INCLUDE_EXTENSIONS = {
    ".py", ".json", ".txt", ".md", ".env", ".ttf", ".bat"
}

EXCLUDE_DIRS = {
    "__pycache__", ".git", ".venv", "output_videos"
}

EXCLUDE_FILES = {
    "cloudflared.exe", "test_tts.mp3", OUTPUT_ZIP
}

def create_cloud_package():
    print("=" * 65)
    print("☁️ YOUTUBE AI STUDIO — BULUTGA YUKLASH PAKETI YARATILMOQDA")
    print("=" * 65)

    base_dir = Path(".")
    total_files = 0
    total_size = 0

    with zipfile.ZipFile(OUTPUT_ZIP, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(base_dir):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]

            for file in files:
                if file in EXCLUDE_FILES:
                    continue
                ext = Path(file).suffix.lower()
                if ext in INCLUDE_EXTENSIONS or file in ("Dockerfile", "packages.txt", "requirements.txt", ".env"):
                    file_path = Path(root) / file
                    arcname = file_path.relative_to(base_dir)
                    zipf.write(file_path, arcname)
                    total_files += 1
                    total_size += file_path.stat().st_size

    print(f"\n[+] Muvaffaqiyatli arxivlandi: '{OUTPUT_ZIP}'")
    print(f"📦 Jami fayllar soni: {total_files} ta")
    print(f"⚖️ Arxiv hajmi: {os.path.getsize(OUTPUT_ZIP) / 1024:.1f} KB (juda yengil!)")
    print("\n" + "=" * 65)
    print("📱 HUGGING FACE SPACES GA 2 DAQIQADA O'RNATISH QADAMLARI:")
    print("=" * 65)
    print("1. Brauzerda https://huggingface.co saytiga kiring (bepul ro'yxatdan o'ting).")
    print("2. Profilingizdan 'New Space' tugmasini bosing:")
    print("   - Space name: youtube-studio")
    print("   - Space SDK: Streamlit ni tanlang")
    print("   - Visibility: Public yoki Private (xohlaganingiz)")
    print("3. 'Create Space' tugmasini bosing.")
    print("4. Hosil bo'lgan sahifada 'Files' -> 'Upload files' ni bosing.")
    print(f"5. Ushbu papkadagi barcha asosiy fayllarni (yoki '{OUTPUT_ZIP}' ichidagilarni) yuklang.")
    print("6. Hugging Face o'zi 1 daqiqada avtomatik ishga tushiradi!")
    print("7. Natijada sizga shaxsiy doimiy havola beriladi!")
    print("   Kompyuteringiz butunlay o'chiq tursa ham, telefoningizdan 24/7 ishlatasiz!")
    print("=" * 65 + "\n")

if __name__ == "__main__":
    create_cloud_package()
